﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _8762034_FinalExam
{
    /// <summary>
    /// made by SATYAM GAJJAR
    /// Student id: 8762034
    ///
    /// 
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //declaring the list
        List<UserItem> useritems = new List<UserItem>();



        public MainWindow()
        {
            InitializeComponent();
        }

        //add button 
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //validation
            try
            {
                int temp = Convert.ToInt32(txtNumber.Text);
                int temp1 = Convert.ToInt32(txtCost.Text);
                int temp2 = Convert.ToInt32(txtQuantity.Text);

                var useritem = new UserItem();

                //conversion
                useritem.itemNumber = Int32.Parse(txtNumber.Text);
                useritem.name = txtName.Text;
                useritem.cost = Double.Parse(txtCost.Text);
                useritem.quantity = Int32.Parse(txtQuantity.Text);

                //adding to list
                useritems.Add(useritem);
                //adding to grid
                updateGrid(useritems);
            }
            catch (Exception h)
            {
                MessageBox.Show("Please provide all data. 1) Add Integer in Number and Quantity field and Cost field.");
            }

        }


        //update grid
        public void updateGrid(List<UserItem> _items)
        {
            finalOutput.ItemsSource = _items;
            finalOutput.Items.Refresh();
        }

        //save button
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                string itemsJson = JsonConvert.SerializeObject(useritems);
                saveData(itemsJson);
            }
            catch (Exception ex)
            {
                string saveError = "";
                saveError = "Error! Please try in another way";
                MessageBox.Show(saveError, "Error!", MessageBoxButton.OK);
            }
        }

        //saving the file to external folder
        public void saveData(string data)
        {
            File.WriteAllText("Output_User.json", data);

            string save = "";
            save = "File is Saved!";
            MessageBox.Show(save, "Success!", MessageBoxButton.OK);
        }

        //load button
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            try
            {
                useritems = loadUsers();
                updateGrid(useritems);


                string load = "";
                load = "Data Loaded Successfully.";
                MessageBox.Show(load, "Success", MessageBoxButton.OK);
            }
            catch(Exception ex)
            {
                string loadError = "";
                loadError = "Error in loading the data";
                MessageBox.Show(loadError, "Error!", MessageBoxButton.OK);

            }
        }

        //load data function
        public List<UserItem> loadUsers()
        {
            string useritemsJson = File.ReadAllText("Output_User.json");
            return JsonConvert.DeserializeObject<List<UserItem>>(useritemsJson);


        }

        //clear all
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            try
            {


                //clear the list
                useritems.Clear();
                finalOutput.Items.Refresh();


                string deletePass = "";
                deletePass = "Inventory is cleared!";
                MessageBox.Show(deletePass, "Success", MessageBoxButton.OK);
            }
            catch (Exception ex)
            {
                string clearError = "";
                clearError = "Error in clearing the data";
                MessageBox.Show(clearError, "Error!", MessageBoxButton.OK);

            }
        }

        //exit the program
        private void Button_Click_Exit(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        //delete button
            
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            string clearError = "";
            clearError = "Error!";
            MessageBox.Show(clearError, "Error", MessageBoxButton.OK);

        }
    }
}

