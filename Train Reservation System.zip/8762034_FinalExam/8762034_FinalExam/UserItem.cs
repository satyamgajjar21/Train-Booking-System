﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _8762034_FinalExam
{
    public class UserItem
    {
        public int itemNumber { get; set; }
        public string name { get; set; }
        public double cost { get; set; }
        public int quantity { get; set; }

    }


}
